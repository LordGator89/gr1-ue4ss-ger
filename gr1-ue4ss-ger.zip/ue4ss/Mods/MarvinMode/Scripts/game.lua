-- MarvinMode - Spiel-Adapter
-- Die einzige Datei, die UE4SS-/Engine-Objekte anfasst. Alles ist pcall-geschuetzt.
-- Wichtig: pcall faengt KEINE nativen Zugriffsverletzungen ab. Deshalb nutzen wir nur
-- Funktionen und Properties, die im Gothic 1 Remake nachweislich funktionieren:
--   * Attribut-Sets (AttributeSet_*) des Spielers per Reflection lesen/schreiben
--   * CombatConfig.m_GodMode / m_ParryCheatMode (die eingebauten Cheat-Flags des Spiels)
--   * GAS-Mixin-Bibliotheken (Heal, LearnSkillForFree, Inventar)
--   * MapData:TeleportActorToNormalized2DPosition (die Schnellreise des Spiels)
--   * AngelscriptActorLibrary:AddActorWorldOffset (K2_SetActorLocation ist hier kaputt)

local pcall, ipairs, pairs, type, tostring, tonumber = pcall, ipairs, pairs, type, tostring, tonumber
local math, string = math, string

local FindAllOf             = rawget(_G, "FindAllOf")
local FindFirstOf           = rawget(_G, "FindFirstOf")
local StaticFindObject      = rawget(_G, "StaticFindObject")
local StaticConstructObject = rawget(_G, "StaticConstructObject")
local FName                 = rawget(_G, "FName")

local game = {}

-- ------------------------------------------------------------------ Basics --

local function isValid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v == true
end
game.isValid = isValid

local function try(fn)
    local ok, v = pcall(fn)
    if ok then return v end
    return nil
end

local function fullName(o)
    return try(function() return o:GetFullName() end) or ""
end

local function shortName(o)
    return try(function() return o:GetFName():ToString() end) or fullName(o)
end
game.shortName = shortName

local function liveInstances(className)
    local out = {}
    if not FindAllOf then return out end
    local list = try(function() return FindAllOf(className) end)
    if type(list) ~= "table" then return out end
    for _, o in ipairs(list) do
        if isValid(o) and not fullName(o):find("Default__", 1, true) then
            out[#out + 1] = o
        end
    end
    return out
end

local SCRIPT_PACKAGES = { "/Script/Angelscript.", "/Script/AngelscriptCode.", "/Script/G1R.", "/Script/Engine." }

-- Klassen-Default-Objekt einer Funktionsbibliothek (z. B. die GAS-Mixins).
local libCache = {}
function game.lib(className)
    local hit = libCache[className]
    if isValid(hit) then return hit end
    libCache[className] = nil
    if not StaticFindObject then return nil end
    for _, pkg in ipairs(SCRIPT_PACKAGES) do
        local cdo = try(function() return StaticFindObject(pkg .. "Default__" .. className) end)
        if isValid(cdo) then libCache[className] = cdo; return cdo end
    end
    return nil
end

-- Klasse per Kurzname finden (Items "It*", Skills "GE_Skill_*", Engine-Klassen ...).
local classCache = {}
function game.resolveClass(name)
    if not name or name == "" then return nil end
    local hit = classCache[name]
    if hit ~= nil then return hit or nil end
    local found
    if StaticFindObject then
        if name:find("/", 1, true) then
            local c = try(function() return StaticFindObject(name) end)
            if isValid(c) then found = c end
        else
            for _, form in ipairs({ name, name .. "_C" }) do
                for _, pkg in ipairs(SCRIPT_PACKAGES) do
                    local c = try(function() return StaticFindObject(pkg .. form) end)
                    if isValid(c) then found = c; break end
                end
                if found then break end
            end
        end
    end
    classCache[name] = found or false
    return found or nil
end

-- ------------------------------------------------------------------ Spieler --

local pawnCache
function game.pawn()
    if isValid(pawnCache) then return pawnCache end
    pawnCache = liveInstances("GothicPlayerCharacter")[1]
    return pawnCache
end

function game.state(pawn)
    pawn = pawn or game.pawn()
    if not isValid(pawn) then return nil end
    local s = try(function() return pawn.PlayerState end)
    if isValid(s) then return s end
    s = try(function() return pawn.m_CharacterState end)
    return isValid(s) and s or nil
end

function game.controller(pawn)
    pawn = pawn or game.pawn()
    if not isValid(pawn) then return nil end
    local pc = try(function() return pawn.Controller end)
    return isValid(pc) and pc or nil
end

function game.world()
    local pawn = game.pawn()
    local w = pawn and try(function() return pawn:GetWorld() end)
    if isValid(w) then return w end
    w = FindFirstOf and try(function() return FindFirstOf("World") end)
    return isValid(w) and w or nil
end

-- Attribut-Set des SPIELERS (die Instanz, deren Pfad "PlayerState" enthaelt).
local attrCache = {}
function game.attrSet(className)
    local hit = attrCache[className]
    if isValid(hit) and fullName(hit):find("PlayerState", 1, true) then return hit end
    attrCache[className] = nil
    for _, s in ipairs(liveInstances(className)) do
        if fullName(s):find("PlayerState", 1, true) then
            attrCache[className] = s
            return s
        end
    end
    return nil
end

function game.readAttr(set, attr)
    if not set then return nil end
    local v = try(function() return set[attr].CurrentValue end)
    if type(v) == "number" then return v end
    v = try(function() return set[attr].BaseValue end)
    if type(v) == "number" then return v end
    return nil
end

-- Attribut auf einen Zielwert bringen. Base und Current werden um dieselbe Differenz
-- verschoben, damit Boni (Ringe, Traenke ...) erhalten bleiben.
function game.setAttr(set, attr, target)
    if not set then return false end
    return (pcall(function()
        local a = set[attr]
        local cur = a.CurrentValue
        local delta = target - cur
        a.BaseValue = a.BaseValue + delta
        a.CurrentValue = target
    end))
end

-- Nur den aktuellen Wert setzen (fuer Leben/Mana/Sauerstoff, deren Maximum separat ist).
function game.setAttrCurrent(set, attr, value)
    if not set then return false end
    return (pcall(function()
        local a = set[attr]
        a.BaseValue = value
        a.CurrentValue = value
    end))
end

function game.clearCaches()
    pawnCache = nil
    for k in pairs(attrCache) do attrCache[k] = nil end
    game._clock = nil
    game._mapData = nil
end

-- --------------------------------------------------------- Kampf / Godmode --

-- Echte Heilung ueber das GAS-Mixin des Spiels (die Lebensleiste aktualisiert sich).
function game.heal(amount)
    local pawn = game.pawn()
    local lib = game.lib("Module_GAS_GASCharacterMixinsStatics")
    if not (isValid(pawn) and lib) then return false end
    return (pcall(function() lib:Heal(pawn, amount or 1000000.0, pawn) end))
end

-- Die Cheat-Flags des Spiels stehen in CombatConfig (CDO + ggf. Live-Instanzen).
function game.setCombatFlag(field, value)
    local targets = liveInstances("CombatConfig")
    if StaticFindObject then
        local cdo = try(function() return StaticFindObject("/Script/G1R.Default__CombatConfig") end)
        if isValid(cdo) then targets[#targets + 1] = cdo end
    end
    local any = false
    for _, c in ipairs(targets) do
        if pcall(function() c[field] = value end) then any = true end
    end
    return any
end

-- Strength/Dexterity/MaxMana ueber die Spiel-Mixins erhoehen (wie beim Lehrer).
function game.increaseStatViaMixin(fnName, delta)
    local pawn, state = game.pawn(), game.state()
    local lib = game.lib("Module_GAS_GASCharacterStateMixinsStatics")
    if not (isValid(pawn) and state and lib) then return false end
    return (pcall(function() lib[fnName](lib, state, delta, pawn) end))
end

-- ----------------------------------------------------------- Position/Teleport --

function game.pos(actor)
    actor = actor or game.pawn()
    if not isValid(actor) then return nil end
    local rc = try(function() return actor.RootComponent end)
    if not isValid(rc) then return nil end
    local x, y, z
    local ok = pcall(function() local v = rc:K2_GetComponentLocation(); x, y, z = v.X, v.Y, v.Z end)
    if ok and type(x) == "number" then return x, y, z end
    ok = pcall(function() local v = rc.RelativeLocation; x, y, z = v.X, v.Y, v.Z end)
    if ok and type(x) == "number" then return x, y, z end
    return nil
end

function game.offset(actor, dx, dy, dz)
    if not isValid(actor) then return false end
    local lib = game.lib("AngelscriptActorLibrary")
    if not lib then return false end
    return (pcall(function() lib:AddActorWorldOffset(actor, { X = dx, Y = dy, Z = dz }) end))
end

-- Direkt an eine Weltposition setzen (ohne Kollisionspruefung).
function game.setPos(x, y, z)
    local pawn = game.pawn()
    local cx, cy, cz = game.pos(pawn)
    if not cx then return false end
    return game.offset(pawn, x - cx, y - cy, z - cz)
end

-- Blickrichtung (Yaw, Pitch in Grad) aus der ControlRotation.
function game.viewRotation()
    local pc = game.controller()
    if not pc then return nil end
    local yaw, pitch
    pcall(function() local r = pc.ControlRotation; yaw, pitch = r.Yaw, r.Pitch end)
    if type(yaw) == "number" then return yaw, pitch end
    return nil
end

-- Die Schnellreise-Funktion des Spiels: laedt das Zielgebiet und setzt auf festen Boden.
-- Umrechnung Welt -> normierte Kartenkoordinate (linear, gemessen von der Community).
local MAP = { x0 = 116876, xk = 110788, y0 = -104711, yk = 59388 }
function game.travel(x, y)
    local pawn = game.pawn()
    if not isValid(pawn) then return false, "kein Spieler" end
    local md = game._mapData
    if not isValid(md) then
        local cdo = StaticFindObject and try(function() return StaticFindObject("/Script/G1R.Default__MapData") end)
        if isValid(cdo) then md = try(function() return cdo:GetInstance() end) end
        if not isValid(md) then md = liveInstances("MapData")[1] end
        game._mapData = md
    end
    if not isValid(md) then return false, "MapData nicht gefunden" end
    local nx, ny = (MAP.x0 - x) / MAP.xk, (MAP.y0 - y) / MAP.yk
    local ok = pcall(function() md:TeleportActorToNormalized2DPosition(pawn, { X = nx, Y = ny }) end)
    if not ok then return false, "Spielfunktion fehlgeschlagen" end
    pawnCache = nil -- die Schnellreise kann den Pawn neu aufbauen
    return true
end

-- ------------------------------------------------------------------ Bewegung --

function game.moveComp(pawn)
    pawn = pawn or game.pawn()
    if not isValid(pawn) then return nil end
    local mc = try(function() return pawn:GetGothicMovementComponent() end)
    if isValid(mc) then return mc end
    mc = try(function() return pawn.CharacterMovement end)
    return isValid(mc) and mc or nil
end

function game.locomotion(pawn)
    local m = try(function() return pawn.m_DataModule_Locomotion end)
    if isValid(m) then return m end
    m = try(function()
        local comp = pawn.m_DataModuleComponent
        return comp:GetLocomotionDataModule(pawn)
    end)
    return isValid(m) and m or nil
end

-- WASD-Eingabe des Spielers in Weltrichtung (x, y) und Staerke 0..1.
function game.moveInput(loco)
    local x, y, amt = 0.0, 0.0, 0.0
    if loco then
        pcall(function() local v = loco.m_LastMovementInput; x, y = v.X, v.Y end)
        pcall(function() amt = loco.m_MovementInputAmount end)
    end
    return tonumber(x) or 0.0, tonumber(y) or 0.0, tonumber(amt) or 0.0
end

function game.setCollision(enabled)
    local pawn = game.pawn()
    if not isValid(pawn) then return false end
    return (pcall(function() pawn:SetActorEnableCollision(enabled) end))
end

-- Bewegungskomponente "einfrieren": keine Schwerkraft, keine Geschwindigkeit.
function game.freezeMovement(mc, loco)
    if mc then
        pcall(function() mc.GravityScale = 0.0 end)
        pcall(function() mc:StopMovementImmediately() end)
        pcall(function() mc:SetMovementMode(3, 0) end) -- Falling: kein Boden-Snapping
    end
    if loco then pcall(function() loco.m_MovementState = 3 end) end
end

function game.flyEnable(speed)
    local pawn = game.pawn()
    local mc = game.moveComp(pawn)
    local saved = {}
    if mc then
        pcall(function() mc:SetCheatFlying(true) end)
        pcall(function() mc.MaxFlySpeed = speed end)
        saved.gravity = try(function() return mc.GravityScale end)
        saved.smoothing = try(function() return mc.NetworkSmoothingMode end)
        pcall(function() mc.GravityScale = 0.0 end)
        pcall(function() mc.NetworkSmoothingMode = 0 end)
    end
    game.setCollision(false)
    return saved
end

function game.flyDisable(saved)
    saved = saved or {}
    local pawn = game.pawn()
    game.setCollision(true)
    local mc = game.moveComp(pawn)
    if mc then
        pcall(function() mc:SetCheatFlying(false) end)
        pcall(function() mc.GravityScale = saved.gravity or 1.0 end)
        if saved.smoothing ~= nil then pcall(function() mc.NetworkSmoothingMode = saved.smoothing end) end
        pcall(function() mc:SetMovementMode(3, 0) end) -- fallen lassen, landet normal
    end
    local loco = pawn and game.locomotion(pawn)
    if loco then pcall(function() loco.m_MovementState = 1 end) end
end

-- ------------------------------------------------------------------ NPCs --

function game.allCharacters()
    local world = game.world()
    local gs = game.lib("GameplayStatics")
    local cls = game.resolveClass("/Script/G1R.GothicCharacter")
    if not (world and gs and cls) then return {} end
    local raw = {}
    pcall(function() gs:GetAllActorsOfClass(world, cls, raw) end)
    local out = {}
    for _, r in ipairs(raw) do
        local a = r
        local got = try(function() return r:get() end)
        if got ~= nil then a = got end
        if isValid(a) then out[#out + 1] = a end
    end
    return out
end

-- ------------------------------------------------------------------ Inventar --

function game.inventory()
    local pawn, state = game.pawn(), game.state()
    if state then
        local inv = try(function() return state.InventoryComponent end)
        if isValid(inv) then return inv end
    end
    local cls = game.resolveClass("InventoryComponent")
    for _, owner in ipairs({ state, pawn }) do
        if isValid(owner) and cls then
            local c = try(function() return owner:GetComponentByClass(cls) end)
            if isValid(c) then return c end
        end
    end
    return nil
end

function game.addItem(itemId, count)
    local inv = game.inventory()
    if not inv then return false, "Inventar nicht gefunden (im Spiel sein)" end
    local cls = game.resolveClass(itemId)
    if not cls then return false, "unbekanntes Item '" .. tostring(itemId) .. "'" end
    local ok = pcall(function() inv:AddItemOfClass(cls, count) end)
    return ok, ok and nil or "Hinzufuegen fehlgeschlagen"
end

function game.countItem(itemId)
    local inv, cls = game.inventory(), game.resolveClass(itemId)
    if not (inv and cls) then return nil end
    return tonumber(try(function() return inv:CountItemsOfClass(cls) end))
end

function game.removeItem(itemId, count)
    local pawn, state = game.pawn(), game.state()
    if not state then return false, "kein Spielerzustand (im Spiel sein)" end
    local cls = game.resolveClass(itemId)
    if not cls then return false, "unbekanntes Item '" .. tostring(itemId) .. "'" end
    local lib = game.lib("Module_GAS_GASCharacterStateMixinsStatics")
    if not lib then return false, "Mixin-Bibliothek nicht gefunden" end
    local ok
    if count then ok = pcall(function() lib:RemoveItemFromInventory(state, cls, count, pawn) end)
    else ok = pcall(function() lib:RemoveAllItemsFromInventory(state, cls, pawn) end) end
    return ok, ok and nil or "Entfernen fehlgeschlagen"
end

function game.learnSkill(name)
    local pawn, state = game.pawn(), game.state()
    if not (isValid(pawn) and state) then return false, "kein Spielerzustand (im Spiel sein)" end
    local cls, full
    for _, cand in ipairs({ name, "GE_Skill_" .. name }) do
        cls = game.resolveClass(cand)
        if cls then full = cand; break end
    end
    if not cls then return false, "unbekanntes Talent '" .. tostring(name) .. "'" end
    local lib = game.lib("Module_GAS_GASCharacterStateMixinsStatics")
    if not lib then return false, "Mixin-Bibliothek nicht gefunden" end
    local ok = pcall(function() lib:LearnSkillForFree(state, cls, pawn) end)
    return ok, ok and full or "LearnSkillForFree fehlgeschlagen"
end

-- ------------------------------------------------------------------ Zeit/Welt --

function game.clock()
    if isValid(game._clock) then return game._clock end
    game._clock = liveInstances("GameTimeSubsystem")[1]
    return game._clock
end

function game.getTime()
    local c = game.clock()
    if not c then return nil end
    local h, m
    pcall(function() local t = c:GetCurrentClockTime(); h, m = t.Hour, t.Minute end)
    if type(h) == "number" then return h, m end
    return nil
end

function game.setTime(h, m)
    local c = game.clock()
    if not c then return false end
    return (pcall(function() c:SetCurrentClockTime(h, m, 0.0) end))
end

function game.skipTime(seconds)
    local c = game.clock()
    if not c then return false end
    return (pcall(function() c:SkipTime({ TotalSeconds = seconds }) end))
end

function game.freezeTime(frozen)
    local c = game.clock()
    if not c then return false end
    if frozen then return (pcall(function() c:FreezeTime() end)) end
    return (pcall(function() c:UnfreezeTime() end))
end

-- Echtzeit in Sekunden (unabhaengig von Zeitlupe), fuer framerate-unabhaengige Bewegung.
function game.realTime()
    local world, gs = game.world(), game.lib("GameplayStatics")
    if not (world and gs) then return nil end
    local t = try(function() return gs:GetRealTimeSeconds(world) end)
    return type(t) == "number" and t or nil
end

function game.setTimeDilation(v)
    local world, gs = game.world(), game.lib("GameplayStatics")
    if not (world and gs) then return false end
    return (pcall(function() gs:SetGlobalTimeDilation(world, v) end))
end

function game.setWeather(id)
    local world, gs = game.world(), game.lib("GameplayStatics")
    if not (world and gs) then return false end
    for _, path in ipairs({ "/Script/G1R.GothicUltraDynamicController", "/Script/G1R.GothicUltraDynamicWeather" }) do
        local cls = game.resolveClass(path)
        if cls then
            local raw = {}
            pcall(function() gs:GetAllActorsOfClass(world, cls, raw) end)
            local a = raw[1]
            if a ~= nil then
                local got = try(function() return a:get() end)
                if got ~= nil then a = got end
                if isValid(a) then
                    if pcall(function() a:SetCurrentWeatherImmediate(id) end) then return true end
                    if pcall(function() a:SetCurrentWeather(id) end) then return true end
                end
            end
        end
    end
    return false
end

-- ------------------------------------------------------------------ Konsole --

-- Erstellt die Unreal-Konsole am GameViewport (im Shipping-Build fehlt sie) und
-- traegt die gewuenschten Konsolentasten ein.
function game.enableConsole(keyNames)
    if not (StaticFindObject and StaticConstructObject and FindFirstOf) then
        return false, "UE4SS-API nicht verfuegbar"
    end
    local gv = try(function() return FindFirstOf("GameViewportClient") end)
    if not isValid(gv) then
        local eng = try(function() return FindFirstOf("GameEngine") end)
        gv = eng and try(function() return eng.GameViewport end)
    end
    if not isValid(gv) then return false, "kein GameViewport" end

    if not isValid(try(function() return gv.ViewportConsole end)) then
        local cls = try(function() return StaticFindObject("/Script/Engine.Console") end)
        if not isValid(cls) then return false, "Console-Klasse fehlt" end
        local con = try(function() return StaticConstructObject(cls, gv) end)
        if not isValid(con) then return false, "Konsole konnte nicht erstellt werden" end
        if not pcall(function() gv.ViewportConsole = con end) then return false, "Zuweisung fehlgeschlagen" end
    end

    local settings = try(function() return StaticFindObject("/Script/Engine.Default__InputSettings") end)
    if FName and isValid(settings) then
        pcall(function()
            local keys = settings.ConsoleKeys
            for _, name in ipairs(keyNames or {}) do
                local fn = FName(name)
                local present = false
                for i = 1, #keys do
                    if try(function() return keys[i].KeyName == fn end) then present = true; break end
                end
                if not present then pcall(function() keys[#keys + 1].KeyName = fn end) end
            end
        end)
    end
    return true
end

return game
