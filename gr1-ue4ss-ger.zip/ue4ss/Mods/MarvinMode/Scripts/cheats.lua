-- MarvinMode - Cheat-Befehle
-- Reine Logik: alle Engine-Zugriffe laufen ueber game.lua.

local ipairs, pairs, tostring, tonumber, type, pcall = ipairs, pairs, tostring, tonumber, type, pcall
local math, string, table, io = math, string, table, io

local M = {}

local game, cfg, log, modDir
local TICK = 0.016 -- Sekunden seit dem letzten Treiber-Tick (setzt M.tick)

-- ------------------------------------------------------------------ Zustand --

local S = {
    god = false, godTimer = 0,
    infMana = false,
    oneHit = false,
    parry = false,
    noclip = false,
    frozenTime = false,
    fly = { on = false, saved = nil, x = nil, y = nil, z = nil, rise = 0 },
    hold = nil,        -- { x, y, z, left, saved } nach einem Fern-Teleport
    history = {},      -- Positionen vor Teleports (fuer tpback)
}

-- ------------------------------------------------------------------ Helfer --

local function lower(s) return s and string.lower(s) or nil end

-- nil = umschalten, true/false = setzen, "bad" = ungueltig
local function toggleArg(a, current)
    a = lower(a)
    if a == nil or a == "" or a == "toggle" then return not current end
    if a == "on" or a == "an" or a == "ein" or a == "1" or a == "true" then return true end
    if a == "off" or a == "aus" or a == "0" or a == "false" then return false end
    return "bad"
end

local function fmt(v, decimals)
    if v == nil then return "?" end
    if decimals then return string.format("%." .. decimals .. "f", v) end
    return string.format("%d", math.floor(v + 0.5))
end

local function onOff(b) return b and "AN" or "AUS" end

local function needPawn(out)
    if game.pawn() then return true end
    out("Kein Spieler gefunden - erst einen Spielstand laden.")
    return false
end

-- ------------------------------------------------------------------ Stats --

-- kind: "stat" = normales Attribut (Boni bleiben erhalten), "pool" = Leben/Mana (nur aktueller Wert)
local STATS = {
    { key = "str",     label = "Staerke",            set = "AttributeSet_Strength",         attr = "Strength",      kind = "stat", aliases = { "strength", "staerke", "st" } },
    { key = "dex",     label = "Geschick",          set = "AttributeSet_Dexterity",        attr = "Dexterity",     kind = "stat", aliases = { "dexterity", "geschick", "ge" } },
    { key = "hp",      label = "Leben",             set = "AttributeSet_Health",           attr = "Health",        kind = "pool", max = "MaxHealth", aliases = { "health", "leben" } },
    { key = "maxhp",   label = "Max. Leben",        set = "AttributeSet_Health",           attr = "MaxHealth",     kind = "stat", aliases = { "maxhealth", "maxleben" } },
    { key = "mana",    label = "Mana",              set = "AttributeSet_Mana",             attr = "Mana",          kind = "pool", max = "MaxMana", aliases = {} },
    { key = "maxmana", label = "Max. Mana",         set = "AttributeSet_Mana",             attr = "MaxMana",       kind = "stat", aliases = {} },
    { key = "level",   label = "Stufe",             set = "AttributeSet_LevelProgression", attr = "Level",         kind = "stat", aliases = { "stufe", "lvl" } },
    { key = "xp",      label = "Erfahrung",         set = "AttributeSet_LevelProgression", attr = "Experience",    kind = "stat", aliases = { "exp", "erfahrung" } },
    { key = "lp",      label = "Lernpunkte",        set = "AttributeSet_LevelProgression", attr = "SkillPoints",   kind = "stat", aliases = { "lernpunkte", "skillpoints" } },
    { key = "speed",   label = "Laufgeschw.",       set = "AttributeSet_Movement",         attr = "SpeedModifier", kind = "stat", decimals = 2, aliases = { "runspeed", "tempo" } },
}

local statByName = {}
for _, d in ipairs(STATS) do
    statByName[d.key] = d
    for _, a in ipairs(d.aliases) do statByName[a] = d end
end

local function readStat(d)
    local set = game.attrSet(d.set)
    return game.readAttr(set, d.attr), set
end

-- Wert-Ausdruck: "100" = setzen, "+10" / "-10" = addieren
local function applyStat(d, expr, out, forceAdd)
    local cur, set = readStat(d)
    if not set or cur == nil then
        out(d.label .. ": Attribut nicht gefunden (im Spiel sein).")
        return
    end
    local n = tonumber(expr)
    if not n then out("Ungueltiger Wert: " .. tostring(expr)); return end
    local relative = forceAdd or expr:sub(1, 1) == "+" or expr:sub(1, 1) == "-"
    local target = relative and (cur + n) or n
    if target < 0 then target = 0 end

    local ok
    if d.kind == "pool" then
        local maxv = game.readAttr(set, d.max)
        if maxv and target > maxv then
            game.setAttr(set, d.max, target) -- Maximum mit anheben
        end
        ok = game.setAttrCurrent(set, d.attr, target)
    else
        ok = game.setAttr(set, d.attr, target)
        -- aktuellen Wert nicht ueber das neue Maximum stehen lassen
        if ok and d.attr == "MaxHealth" then
            local hp = game.readAttr(set, "Health")
            if hp and hp > target then game.setAttrCurrent(set, "Health", target) end
        elseif ok and d.attr == "MaxMana" then
            local mp = game.readAttr(set, "Mana")
            if mp and mp > target then game.setAttrCurrent(set, "Mana", target) end
        end
    end
    if ok then
        out(string.format("%s: %s -> %s", d.label, fmt(cur, d.decimals), fmt(target, d.decimals)))
    else
        out(d.label .. ": Schreiben fehlgeschlagen.")
    end
end

local function showStats(out)
    if not needPawn(out) then return end
    out("---- Werte des Helden ----")
    for _, d in ipairs(STATS) do
        local v = readStat(d)
        local line = string.format("  %-8s %-18s %s", d.key, d.label, fmt(v, d.decimals))
        if d.kind == "pool" then
            local set = game.attrSet(d.set)
            line = line .. " / " .. fmt(game.readAttr(set, d.max))
        end
        out(line)
    end
    out("Aendern: <stat> <wert> | <stat> +<n> | <stat> -<n>   (z. B. 'str 100', 'lp +20')")
end

-- ------------------------------------------------------------------ Ressourcen --

local function fillPool(setName, attr, maxAttr)
    local set = game.attrSet(setName)
    local maxv = game.readAttr(set, maxAttr)
    if not maxv then return false end
    local cur = game.readAttr(set, attr)
    if cur and cur >= maxv then return true end
    return game.setAttrCurrent(set, attr, maxv)
end

local function healFull()
    if game.heal() then return true end
    return fillPool("AttributeSet_Health", "Health", "MaxHealth")
end

local function fullRestore(out)
    if not needPawn(out) then return end
    local hp = healFull()
    local mp = fillPool("AttributeSet_Mana", "Mana", "MaxMana")
    local ox = fillPool("AttributeSet_Oxygen", "Oxygen", "MaxOxygen")
    local fat = game.setAttrCurrent(game.attrSet("AttributeSet_Fatigue"), "Fatigue", 0)
    out(string.format("Aufgefuellt: Leben %s, Mana %s, Sauerstoff %s, Muedigkeit %s",
        hp and "ok" or "-", mp and "ok" or "-", ox and "ok" or "-", fat and "weg" or "-"))
end

local function setGod(want, out)
    local flagged = game.setCombatFlag("m_GodMode", want)
    S.god = want
    S.godTimer = 0
    if want then healFull() end
    out("Godmode " .. onOff(want) .. (want and (flagged and " (unverwundbar + Dauerheilung)"
        or " (nur Dauerheilung - CombatConfig nicht gefunden)") or ""))
end

local ONEHIT_BOOST = 100000
local function setOneHit(want, out)
    if want == S.oneHit then out("One-Hit ist bereits " .. onOff(want)); return end
    for _, key in ipairs({ "str", "dex" }) do
        local d = statByName[key]
        local cur, set = readStat(d)
        if cur and set then
            if want then
                game.setAttr(set, d.attr, cur + ONEHIT_BOOST)
            elseif cur >= ONEHIT_BOOST then
                game.setAttr(set, d.attr, cur - ONEHIT_BOOST)
            end
        end
    end
    S.oneHit = want
    out("One-Hit-Kills " .. onOff(want) .. (want and " (vor dem Speichern wieder ausschalten!)" or ""))
end

-- ------------------------------------------------------------------ Teleport --

local function remember()
    local x, y, z = game.pos()
    if x then
        table.insert(S.history, { x, y, z })
        if #S.history > 20 then table.remove(S.history, 1) end
    end
end

-- Direkt an eine Position springen und kurz festhalten, bis die Welt geladen ist.
local function jumpTo(x, y, z, holdSeconds)
    local pawn = game.pawn()
    if not pawn then return false end
    remember()
    if not game.setPos(x, y, z + 60) then return false end
    if not S.fly.on then
        -- laeuft schon ein Halten, ist die Schwerkraft dort bereits gemerkt (aktuell steht sie auf 0)
        local keep = S.hold and S.hold.saved
        if not keep then
            local mc = game.moveComp(pawn)
            local ok, g = pcall(function() return mc.GravityScale end)
            keep = { gravity = (ok and type(g) == "number") and g or nil }
        end
        S.hold = { x = x, y = y, z = z + 60, left = holdSeconds or cfg.landingHold or 2.5, saved = keep }
    else
        S.fly.x, S.fly.y, S.fly.z = x, y, z + 60
    end
    return true
end

local function travelTo(x, y, out)
    remember()
    local ok, why = game.travel(x, y)
    if ok then
        out(string.format("Schnellreise nach %s / %s ...", fmt(x), fmt(y)))
    else
        table.remove(S.history)
        out("Teleport fehlgeschlagen: " .. tostring(why))
    end
end

-- gespeicherte Positionen (Datei im Mod-Ordner)
local saved = {}
local function savedFile() return (modDir or ".") .. "/saved_positions.txt" end

local function loadSaved()
    saved = {}
    local f = io.open(savedFile(), "r")
    if not f then return end
    for line in f:lines() do
        local name, x, y, z = line:match("^(%S+)%s+(%-?[%d%.]+)%s+(%-?[%d%.]+)%s+(%-?[%d%.]+)")
        if name then saved[lower(name)] = { tonumber(x), tonumber(y), tonumber(z) } end
    end
    f:close()
end

local function writeSaved()
    local f = io.open(savedFile(), "w")
    if not f then return false end
    f:write("# MarvinMode gespeicherte Positionen: name x y z\n")
    local names = {}
    for n in pairs(saved) do names[#names + 1] = n end
    table.sort(names)
    for _, n in ipairs(names) do
        local p = saved[n]
        f:write(string.format("%s %.0f %.0f %.0f\n", n, p[1], p[2], p[3]))
    end
    f:close()
    return true
end

local LOCATIONS = {}
local function findLocation(name)
    name = lower(name)
    if saved[name] then
        local p = saved[name]
        return { name = name, x = p[1], y = p[2], z = p[3] }
    end
    for _, l in ipairs(LOCATIONS) do
        if l.id == name then return l end
        for _, a in ipairs(l.aliases or {}) do if a == name then return l end end
    end
    return nil
end

local function listPlaces(out)
    out("---- Teleport-Ziele (tp <name>) ----")
    for _, l in ipairs(LOCATIONS) do out(string.format("  %-12s %s", l.id, l.name)) end
    local names = {}
    for n in pairs(saved) do names[#names + 1] = n end
    table.sort(names)
    if #names > 0 then
        out("  Eigene (savepos): " .. table.concat(names, ", "))
    end
    out("Weitere: tp <x> <y> [z] | tpf [meter] | tpz <meter> | goto <npc> | tpback")
end

local function tpForward(meters, out)
    if not needPawn(out) then return end
    local yaw = game.viewRotation()
    local x, y, z = game.pos()
    if not (yaw and x) then out("Blickrichtung/Position nicht lesbar."); return end
    local d = (meters or cfg.tpForwardMeters or 6) * 100
    local r = yaw * math.pi / 180
    remember()
    if game.offset(game.pawn(), math.cos(r) * d, math.sin(r) * d, 0) then
        if S.fly.on then S.fly.x, S.fly.y = x + math.cos(r) * d, y + math.sin(r) * d end
        out(string.format("%.1f m nach vorne teleportiert.", d / 100))
    else
        out("Teleport fehlgeschlagen.")
    end
end

local function tpBack(out)
    local p = table.remove(S.history)
    if not p then out("Keine vorherige Position gespeichert."); return end
    local x, y, z = p[1], p[2], p[3]
    if jumpTo(x, y, z - 60, 1.5) then
        table.remove(S.history) -- jumpTo hat die aktuelle Position wieder gemerkt
        out("Zurueck zur vorherigen Position.")
    else
        out("Teleport fehlgeschlagen.")
    end
end

-- ------------------------------------------------------------------ NPCs --

local function npcList(filter)
    local px, py, pz = game.pos()
    local me = game.pawn()
    local list = {}
    if not px then return list end
    filter = lower(filter)
    for _, a in ipairs(game.allCharacters()) do
        if a ~= me then
            local name = game.shortName(a)
            if not filter or lower(name):find(filter, 1, true) then
                local x, y, z = game.pos(a)
                if x then
                    local dist = math.sqrt((x - px) ^ 2 + (y - py) ^ 2 + (z - pz) ^ 2)
                    list[#list + 1] = { actor = a, name = name, dist = dist, x = x, y = y, z = z }
                end
            end
        end
    end
    table.sort(list, function(a, b) return a.dist < b.dist end)
    return list
end

-- ------------------------------------------------------------------ Fliegen --

local function setFly(want, out)
    if not needPawn(out) then return end
    if want == S.fly.on then out("Fliegen ist bereits " .. onOff(want)); return end
    if want then
        if S.hold then S.hold = nil end
        S.fly.saved = game.flyEnable(cfg.flySpeed or 1500)
        S.fly.x, S.fly.y, S.fly.z = nil, nil, nil
        S.fly.rise = 300
        S.fly.on = true
        out("Fliegen AN: WASD + Maus steuern, nach oben schauen = steigen. Nicht in einer Wand ausschalten!")
    else
        S.fly.on = false
        game.flyDisable(S.fly.saved)
        S.fly.saved = nil
        out("Fliegen AUS.")
    end
end

local function flyTick()
    local pawn = game.pawn()
    if not pawn then return end
    local mc, loco = game.moveComp(pawn), game.locomotion(pawn)
    game.freezeMovement(mc, loco)
    if not S.fly.x then
        local x, y, z = game.pos(pawn)
        if not x then return end
        S.fly.x, S.fly.y, S.fly.z = x, y, z
    end
    local speed = cfg.flySpeed or 1500
    local dx, dy, dz = 0, 0, 0
    if S.fly.rise > 0 then
        dz = math.min(S.fly.rise, 600 * TICK)
        S.fly.rise = S.fly.rise - dz
    else
        local ix, iy, amt = game.moveInput(loco)
        local yaw, pitch = game.viewRotation()
        if amt > 0.05 and yaw then
            local len = math.sqrt(ix * ix + iy * iy)
            if len > 0.0001 then ix, iy = ix / len, iy / len end
            local yr, pr = yaw * math.pi / 180, pitch * math.pi / 180
            local fhx, fhy = math.cos(yr), math.sin(yr)   -- vorwaerts (horizontal)
            local rx, ry = -math.sin(yr), math.cos(yr)    -- rechts
            local fwd = ix * fhx + iy * fhy
            local right = ix * rx + iy * ry
            local cp = math.cos(pr)
            local mx = fhx * cp * fwd + rx * right
            local my = fhy * cp * fwd + ry * right
            local mz = math.sin(pr) * fwd
            local mlen = math.sqrt(mx * mx + my * my + mz * mz)
            if mlen > 0.01 then
                local step = speed * TICK / mlen
                dx, dy, dz = mx * step, my * step, mz * step
            end
        end
    end
    S.fly.x, S.fly.y, S.fly.z = S.fly.x + dx, S.fly.y + dy, S.fly.z + dz
    local cx, cy, cz = game.pos(pawn)
    if cx then game.offset(pawn, S.fly.x - cx, S.fly.y - cy, S.fly.z - cz) end
end

local function holdTick()
    local h = S.hold
    local pawn = game.pawn()
    if not pawn then S.hold = nil; return end
    h.left = h.left - TICK
    local mc, loco = game.moveComp(pawn), game.locomotion(pawn)
    if h.left > 0 then
        game.freezeMovement(mc, loco)
        local cx, cy, cz = game.pos(pawn)
        if cx and ((cx - h.x) ^ 2 + (cy - h.y) ^ 2 + (cz - h.z) ^ 2) > 400 then
            game.offset(pawn, h.x - cx, h.y - cy, h.z - cz)
        end
        return
    end
    -- loslassen: Schwerkraft zurueck, normal landen
    if mc then
        local g = h.saved and h.saved.gravity
        pcall(function() mc.GravityScale = (type(g) == "number" and g > 0) and g or 1.0 end)
        pcall(function() mc:SetMovementMode(3, 0) end)
    end
    S.hold = nil
end

-- ------------------------------------------------------------------ Befehle --

local SKILLS = "Acrobatics, Sneak, Wallclimbing, Diving, Riding, Scavenging, Mining_Master, " ..
    "Picklock_Master, Pickpocket_Master, Melee_OneHanded_Master, Melee_TwoHanded_Master, " ..
    "Melee_Fists_Master, Melee_Orc_Master, Ranged_Bow_Master, Ranged_Crossbow_Master, " ..
    "Mage_Circle_1 .. Mage_Circle_6, Crafting_Alchemy, Crafting_Blacksmith_Master, " ..
    "Crafting_Inscription, Orcish_Master, Hunting_Skin_Trained, Hunting_Teeth_Trained, ..."

local WEATHER = { sonne = 0, sunny = 0, klar = 0, regen = 1, rain = 1, starkregen = 2, rain2 = 2,
    sturm = 3, gewitter = 3, storm = 3, wolken = 4, bewoelkt = 4, cloudy = 4 }

local commands = {}
local byName = {}

local function cmd(names, usage, help, run)
    local c = { names = names, usage = usage, help = help, run = run }
    commands[#commands + 1] = c
    for _, n in ipairs(names) do byName[n] = c end
end

cmd({ "god", "godmode" }, "god [an|aus]", "Godmode: unverwundbar + Dauerheilung", function(a, out)
    local w = toggleArg(a[1], S.god)
    if w == "bad" then out("Nutzung: god [an|aus]"); return end
    setGod(w, out)
end)

cmd({ "heal", "heilen" }, "heal", "Leben voll auffuellen", function(a, out)
    if not needPawn(out) then return end
    out(healFull() and "Leben aufgefuellt." or "Heilen fehlgeschlagen.")
end)

cmd({ "full", "voll" }, "full", "Leben, Mana, Sauerstoff voll + Muedigkeit weg", function(a, out)
    fullRestore(out)
end)

cmd({ "infmana", "manainf" }, "infmana [an|aus]", "Unendlich Mana", function(a, out)
    local w = toggleArg(a[1], S.infMana)
    if w == "bad" then out("Nutzung: infmana [an|aus]"); return end
    S.infMana = w
    out("Unendlich Mana " .. onOff(w))
end)

cmd({ "onehit" }, "onehit [an|aus]", "One-Hit-Kills (riesige Staerke/Geschick)", function(a, out)
    if not needPawn(out) then return end
    local w = toggleArg(a[1], S.oneHit)
    if w == "bad" then out("Nutzung: onehit [an|aus]"); return end
    setOneHit(w, out)
end)

cmd({ "parry", "autoparry" }, "parry [an|aus]", "Automatisch jeden Nahkampfangriff parieren", function(a, out)
    local w = toggleArg(a[1], S.parry)
    if w == "bad" then out("Nutzung: parry [an|aus]"); return end
    if game.setCombatFlag("m_ParryCheatMode", w) then
        S.parry = w
        out("Auto-Parieren " .. onOff(w))
    else
        out("CombatConfig nicht gefunden (im Spiel sein).")
    end
end)

-- Stats-Editor
cmd({ "stats", "werte", "attributes" }, "stats", "Alle Werte des Helden anzeigen", function(a, out)
    showStats(out)
end)

cmd({ "setstat" }, "setstat <stat> <wert>", "Stat auf Wert setzen", function(a, out)
    local d = statByName[lower(a[1] or "")]
    if not d or not a[2] then out("Nutzung: setstat <stat> <wert>   Stats: str dex hp maxhp mana maxmana level xp lp speed"); return end
    if not needPawn(out) then return end
    applyStat(d, a[2], out, false)
end)

cmd({ "addstat" }, "addstat <stat> <n>", "Stat um n erhoehen (negativ = senken)", function(a, out)
    local d = statByName[lower(a[1] or "")]
    if not d or not a[2] then out("Nutzung: addstat <stat> <n>"); return end
    if not needPawn(out) then return end
    applyStat(d, a[2], out, true)
end)

for _, d in ipairs(STATS) do
    local names = { d.key }
    for _, al in ipairs(d.aliases) do names[#names + 1] = al end
    cmd(names, d.key .. " [wert|+n|-n]", d.label .. " anzeigen/aendern", function(a, out)
        if not needPawn(out) then return end
        if not a[1] then
            local v, set = readStat(d)
            if d.kind == "pool" then
                out(d.label .. " = " .. fmt(v) .. " / " .. fmt(game.readAttr(set, d.max)))
            else
                out(d.label .. " = " .. fmt(v, d.decimals))
            end
            return
        end
        applyStat(d, a[1], out, false)
    end)
end

-- Teleport
cmd({ "pos", "where", "position" }, "pos", "Aktuelle Position anzeigen", function(a, out)
    local x, y, z = game.pos()
    if not x then out("Position nicht lesbar (im Spiel sein)."); return end
    out(string.format("Position: %.0f %.0f %.0f", x, y, z))
end)

cmd({ "tp", "teleport", "goto_pos" }, "tp <ort> | tp <x> <y> [z]", "Teleportieren", function(a, out)
    if not a[1] then listPlaces(out); return end
    if not needPawn(out) then return end
    local x, y, z = tonumber(a[1]), tonumber(a[2]), tonumber(a[3])
    if x and y then
        if z then
            if jumpTo(x, y, z) then out(string.format("Teleportiert nach %.0f %.0f %.0f", x, y, z))
            else out("Teleport fehlgeschlagen.") end
        else
            travelTo(x, y, out)
        end
        return
    end
    local l = findLocation(a[1])
    if not l then out("Unbekanntes Ziel '" .. a[1] .. "'. 'tp' ohne Angabe listet alle Ziele."); return end
    if l.z then
        if jumpTo(l.x, l.y, l.z) then out("Teleportiert: " .. (l.name or a[1])) else out("Teleport fehlgeschlagen.") end
    else
        travelTo(l.x, l.y, out)
    end
end)

cmd({ "orte", "places", "locations" }, "orte", "Teleport-Ziele auflisten", function(a, out) listPlaces(out) end)

cmd({ "tpf", "forward" }, "tpf [meter]", "Nach vorne teleportieren (durch Waende)", function(a, out)
    tpForward(tonumber(a[1]), out)
end)

cmd({ "tpz", "up" }, "tpz <meter>", "Nach oben (negativ: unten) teleportieren", function(a, out)
    if not needPawn(out) then return end
    local m = tonumber(a[1])
    if not m then out("Nutzung: tpz <meter>"); return end
    remember()
    if game.offset(game.pawn(), 0, 0, m * 100) then
        if S.fly.on and S.fly.z then S.fly.z = S.fly.z + m * 100 end
        out(string.format("%.1f m %s teleportiert.", math.abs(m), m >= 0 and "nach oben" or "nach unten"))
    else
        out("Teleport fehlgeschlagen.")
    end
end)

cmd({ "tpback", "back", "zurueck" }, "tpback", "Zurueck zur Position vor dem letzten Teleport", function(a, out)
    if not needPawn(out) then return end
    tpBack(out)
end)

cmd({ "savepos" }, "savepos <name>", "Aktuelle Position speichern", function(a, out)
    local name = lower(a[1])
    if not name then out("Nutzung: savepos <name>"); return end
    local x, y, z = game.pos()
    if not x then out("Position nicht lesbar (im Spiel sein)."); return end
    saved[name] = { x, y, z }
    out(writeSaved() and ("Position '" .. name .. "' gespeichert. Zurueck mit: tp " .. name)
        or "Gespeichert (nur bis Spielende - Datei nicht beschreibbar).")
end)

cmd({ "delpos" }, "delpos <name>", "Gespeicherte Position loeschen", function(a, out)
    local name = lower(a[1])
    if not name or not saved[name] then out("Unbekannte Position."); return end
    saved[name] = nil
    writeSaved()
    out("Position '" .. name .. "' geloescht.")
end)

cmd({ "npcs", "npclist" }, "npcs [filter]", "Geladene NPCs/Kreaturen in der Naehe auflisten", function(a, out)
    if not needPawn(out) then return end
    local list = npcList(a[1])
    if #list == 0 then out("Keine passenden Charaktere geladen."); return end
    out("---- Charaktere (naechste zuerst) ----")
    for i = 1, math.min(20, #list) do
        out(string.format("  %5.0f m  %s", list[i].dist / 100, list[i].name))
    end
    if #list > 20 then out(string.format("  ... und %d weitere (Filter nutzen: npcs <name>)", #list - 20)) end
end)

cmd({ "goto", "gotonpc" }, "goto <name>", "Zum naechsten passenden NPC teleportieren", function(a, out)
    if not needPawn(out) then return end
    if not a[1] then out("Nutzung: goto <name>  (Namen siehe 'npcs')"); return end
    local t = npcList(a[1])[1]
    if not t then out("Kein geladener Charakter passt zu '" .. a[1] .. "'."); return end
    local px, py = game.pos()
    local dx, dy = px - t.x, py - t.y
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 1 then dx, dy, len = 1, 0, 1 end
    local x, y = t.x + dx / len * 150, t.y + dy / len * 150
    if jumpTo(x, y, t.z, 1.0) then out("Teleportiert zu " .. t.name) else out("Teleport fehlgeschlagen.") end
end)

-- Bewegung
cmd({ "fly", "fliegen" }, "fly [an|aus] [tempo]", "Freies Fliegen ohne Kollision", function(a, out)
    local w = toggleArg(a[1], S.fly.on)
    if w == "bad" then out("Nutzung: fly [an|aus] [tempo cm/s]"); return end
    local sp = tonumber(a[2]); if sp and sp > 0 then cfg.flySpeed = sp end
    setFly(w, out)
end)

cmd({ "flyspeed" }, "flyspeed <cm/s>", "Fluggeschwindigkeit setzen", function(a, out)
    local sp = tonumber(a[1])
    if not sp or sp <= 0 then out("Fluggeschwindigkeit: " .. tostring(cfg.flySpeed)); return end
    cfg.flySpeed = sp
    out("Fluggeschwindigkeit: " .. sp .. " cm/s")
end)

cmd({ "noclip", "ghost" }, "noclip [an|aus]", "Kollision aus (durch Waende laufen)", function(a, out)
    if not needPawn(out) then return end
    local w = toggleArg(a[1], S.noclip)
    if w == "bad" then out("Nutzung: noclip [an|aus]"); return end
    if game.setCollision(not w) then S.noclip = w; out("Noclip " .. onOff(w)) else out("Fehlgeschlagen.") end
end)

-- Items & Talente
cmd({ "item", "give", "insert" }, "item <ItemId> [anzahl]", "Item geben (z. B. ItMi_Orenugget)", function(a, out)
    if not needPawn(out) then return end
    if not a[1] then out("Nutzung: item <ItemId> [anzahl]   z. B. item ItMi_Orenugget 500"); return end
    local n = math.floor(tonumber(a[2]) or 1)
    local ok, why = game.addItem(a[1], n)
    out(ok and (a[1] .. " x" .. n .. " erhalten.") or tostring(why))
end)

cmd({ "removeitem", "take" }, "removeitem <ItemId> [anzahl]", "Item entfernen (ohne Anzahl: alle)", function(a, out)
    if not needPawn(out) then return end
    if not a[1] then out("Nutzung: removeitem <ItemId> [anzahl]"); return end
    local n = tonumber(a[2])
    local ok, why = game.removeItem(a[1], n and math.floor(n) or nil)
    out(ok and (a[1] .. (n and (" x" .. math.floor(n)) or " (alle)") .. " entfernt.") or tostring(why))
end)

cmd({ "ore", "erz" }, "ore <anzahl>", "Erz geben (negativ = abziehen)", function(a, out)
    if not needPawn(out) then return end
    local n = math.floor(tonumber(a[1]) or 0)
    if n == 0 then out("Erz: " .. tostring(game.countItem("ItMi_Orenugget") or "?")); return end
    local ok, why
    if n > 0 then ok, why = game.addItem("ItMi_Orenugget", n)
    else ok, why = game.removeItem("ItMi_Orenugget", -n) end
    out(ok and ("Erz jetzt: " .. tostring(game.countItem("ItMi_Orenugget") or "?")) or tostring(why))
end)

cmd({ "count" }, "count <ItemId>", "Anzahl eines Items im Inventar", function(a, out)
    if not a[1] then out("Nutzung: count <ItemId>"); return end
    out(a[1] .. ": " .. tostring(game.countItem(a[1]) or "?"))
end)

cmd({ "skill", "talent", "learn" }, "skill <Name>", "Talent kostenlos lernen", function(a, out)
    if not needPawn(out) then return end
    if not a[1] then out("Nutzung: skill <Name>   'skills' listet Beispiele."); return end
    local ok, info = game.learnSkill(a[1])
    out(ok and ("Gelernt: " .. info) or tostring(info))
end)

cmd({ "skills", "talente" }, "skills", "Bekannte Talentnamen", function(a, out)
    out("Talente: " .. SKILLS)
end)

-- Zeit & Welt
cmd({ "time", "zeit" }, "time [HH[:MM]]", "Uhrzeit anzeigen/setzen", function(a, out)
    if not a[1] then
        local h, m = game.getTime()
        out(h and string.format("Uhrzeit: %02d:%02d", math.floor(h), math.floor(m or 0)) or "Uhr nicht gefunden (im Spiel sein).")
        return
    end
    local h, m = a[1]:match("^(%d+):?(%d*)$")
    h, m = tonumber(h), tonumber(m) or 0
    if not h or h > 23 or m > 59 then out("Nutzung: time HH:MM"); return end
    out(game.setTime(h, m) and string.format("Uhrzeit auf %02d:%02d gesetzt.", h, m) or "Fehlgeschlagen.")
end)

cmd({ "skiptime" }, "skiptime <stunden>", "Zeit vorspulen", function(a, out)
    local hrs = tonumber(a[1])
    if not hrs or hrs <= 0 then out("Nutzung: skiptime <stunden>"); return end
    out(game.skipTime(hrs * 3600) and (hrs .. " Stunde(n) vorgespult.") or "Fehlgeschlagen.")
end)

cmd({ "freezetime" }, "freezetime [an|aus]", "Tageszeit anhalten", function(a, out)
    local w = toggleArg(a[1], S.frozenTime)
    if w == "bad" then out("Nutzung: freezetime [an|aus]"); return end
    if game.freezeTime(w) then S.frozenTime = w; out("Zeit angehalten: " .. onOff(w)) else out("Fehlgeschlagen.") end
end)

cmd({ "timescale", "slomo", "gamespeed" }, "timescale <faktor>", "Spielgeschwindigkeit (1 = normal)", function(a, out)
    local v = tonumber(a[1])
    if not v or v <= 0 then out("Nutzung: timescale <faktor>  (z. B. 0.5 oder 2)"); return end
    out(game.setTimeDilation(v) and ("Spielgeschwindigkeit: " .. v .. "x") or "Fehlgeschlagen.")
end)

cmd({ "weather", "wetter" }, "weather <sonne|regen|starkregen|sturm|wolken>", "Wetter setzen", function(a, out)
    local id = WEATHER[lower(a[1] or "")] or tonumber(a[1])
    if not id then out("Nutzung: weather <sonne|regen|starkregen|sturm|wolken>"); return end
    out(game.setWeather(id) and "Wetter geaendert." or "Wetter-Controller nicht gefunden.")
end)

-- Hilfe
local function help(out)
    out("======== MarvinMode - Cheats ========")
    for _, c in ipairs(commands) do
        if not c.hidden then out(string.format("  %-34s %s", c.usage, c.help)) end
    end
    out("Alle Befehle gehen auch als 'cheat <befehl>' (z. B. 'cheat god').")
end

cmd({ "marvin", "cheats", "hilfe" }, "marvin", "Diese Hilfe", function(a, out) help(out) end)

cmd({ "cheat" }, "cheat <befehl> [...]", "Wie im Original: cheat god, cheat full ...", function(a, out)
    local name = lower(a[1])
    local c = name and byName[name]
    if not c or c.names[1] == "cheat" then help(out); return end
    local rest = {}
    for i = 2, #a do rest[#rest + 1] = a[i] end
    c.run(rest, out)
end)

-- ------------------------------------------------------------------ API --

function M.init(g, config, dir, logger, locations)
    game, cfg, modDir, log = g, config, dir, logger
    LOCATIONS = locations or {}
    loadSaved()
end

function M.commands() return commands end

function M.find(name) return byName[lower(name)] end

function M.run(c, args, out)
    local ok, err = pcall(c.run, args or {}, out)
    if not ok then out(c.names[1] .. ": Fehler (" .. tostring(err) .. ")") end
end

-- Hotkey-Aktionen (werden vom Treiber im Game-Thread ausgefuehrt)
M.actions = {
    god = function(out) setGod(not S.god, out) end,
    full = function(out) fullRestore(out) end,
    fly = function(out) setFly(not S.fly.on, out) end,
    tpForward = function(out) tpForward(nil, out) end,
    savePos = function(out)
        local x, y, z = game.pos()
        if not x then return end
        saved["hotkey"] = { x, y, z }
        writeSaved()
        out("Position 'hotkey' gespeichert.")
    end,
    loadPos = function(out)
        local p = saved["hotkey"]
        if not p then out("Noch keine Position mit dem Hotkey gespeichert."); return end
        if jumpTo(p[1], p[2], p[3]) then out("Zur Position 'hotkey' teleportiert.") end
    end,
    tpBack = function(out) tpBack(out) end,
}

-- Muss der Treiber gerade etwas tun?
function M.active()
    return S.fly.on or S.hold ~= nil or S.god or S.infMana
end

-- Wird bei jedem Laden eines Spielstands / Levelwechsel aufgerufen.
function M.onWorldChanged()
    S.fly.on, S.fly.saved, S.hold = false, nil, nil
    S.noclip = false
    S.history = {}
    if S.god then game.setCombatFlag("m_GodMode", true) end
    if S.parry then game.setCombatFlag("m_ParryCheatMode", true) end
end

-- Ein Treiber-Tick (Game-Thread, ca. alle 16 ms). dt = vergangene Sekunden.
function M.tick(dt)
    TICK = dt or 0.016
    if S.fly.on then flyTick()
    elseif S.hold then holdTick() end

    if S.god or S.infMana then
        S.godTimer = S.godTimer - TICK
        if S.godTimer <= 0 then
            S.godTimer = cfg.godHealInterval or 0.25
            if game.pawn() then
                if S.god then
                    local set = game.attrSet("AttributeSet_Health")
                    local hp, maxhp = game.readAttr(set, "Health"), game.readAttr(set, "MaxHealth")
                    if hp and maxhp and hp < maxhp then healFull() end
                    fillPool("AttributeSet_Oxygen", "Oxygen", "MaxOxygen")
                end
                if S.infMana then fillPool("AttributeSet_Mana", "Mana", "MaxMana") end
            end
        end
    end
end

return M
