-- MarvinMode fuer Gothic 1 Remake (UE4SS-Lua-Mod)
-- Schaltet die Unreal-Konsole frei und registriert Cheat-Befehle:
-- Godmode, Stats-Editor, Teleport, Items, Talente, Zeit, Wetter, Fliegen ...
-- Hilfe im Spiel: Konsole oeffnen (F10 / Oe / ^) und "marvin" eingeben.

local ipairs, pairs, pcall, print, tostring, type = ipairs, pairs, pcall, print, tostring, type
local rawget, debug, string, table = rawget, debug, string, table

local VERSION = "1.0.0"

local function log(msg) print("[MarvinMode] " .. tostring(msg) .. "\n") end

-- ------------------------------------------------------------- Module laden --
-- Per Pfad laden (nicht require), damit Dateinamen wie "config" nie mit anderen Mods kollidieren.
local source = debug.getinfo(1, "S").source
local ScriptsDir = source:match("^@(.*)[/\\][^/\\]*$")
local ModDir = ScriptsDir and ScriptsDir:match("^(.*)[/\\][^/\\]*$") or nil

local function load(name)
    local ok, mod = false, nil
    if ScriptsDir then ok, mod = pcall(dofile, ScriptsDir .. "/" .. name .. ".lua") end
    if not ok then ok, mod = pcall(require, name) end
    if not ok then log("Fehler beim Laden von " .. name .. ".lua: " .. tostring(mod)); return nil end
    return mod
end

local config    = load("config") or {}
local locations = load("locations") or {}
local game      = load("game")
local cheats    = load("cheats")
if not (game and cheats) then
    log("Kernmodule fehlen - Mod deaktiviert.")
    return
end

config.hotkeys = config.hotkeys or {}
local function dbg(msg) if config.debug then log(msg) end end

cheats.init(game, config, ModDir, log, locations)

-- UE4SS-Funktionen
local RegisterConsoleCommandHandler  = rawget(_G, "RegisterConsoleCommandHandler")
local RegisterKeyBind                = rawget(_G, "RegisterKeyBind")
local RegisterHook                   = rawget(_G, "RegisterHook")
local RegisterInitGameStatePostHook  = rawget(_G, "RegisterInitGameStatePostHook")
local LoopInGameThreadWithDelay      = rawget(_G, "LoopInGameThreadWithDelay")
local LoopAsync                      = rawget(_G, "LoopAsync")
local ExecuteInGameThread            = rawget(_G, "ExecuteInGameThread")
local Key                            = rawget(_G, "Key")

-- ---------------------------------------------------------- Konsolenbefehle --
local prefix = config.commandPrefix or ""
local count = 0
if RegisterConsoleCommandHandler then
    local seen = {}
    for _, c in ipairs(cheats.commands()) do
        for _, name in ipairs(c.names) do
            local full = prefix .. name
            if not seen[full] then
                seen[full] = true
                -- Konsolen-Handler laufen bereits im Game-Thread. Die Ausgabe (Ar) ist nur
                -- waehrend dieses Aufrufs gueltig, also alles sofort und synchron erledigen.
                local ok = pcall(RegisterConsoleCommandHandler, full, function(_, params, ar)
                    local function out(line)
                        pcall(function() ar:Log(line) end)
                        log(line)
                    end
                    local args = {}
                    if type(params) == "table" then
                        for i = 1, #params do args[i] = tostring(params[i]) end
                    end
                    cheats.run(c, args, out)
                    return true
                end)
                if ok then count = count + 1 end
            end
        end
    end
else
    log("RegisterConsoleCommandHandler fehlt - ist UE4SS aktuell?")
end

-- ------------------------------------------------------------------ Treiber --
-- EIN Game-Thread-Treiber erledigt alles Wiederkehrende (Godmode, Fliegen, Hotkeys).
-- Hotkeys setzen nur einen Eintrag in die Warteschlange (sie laufen nicht im Game-Thread).
local pending = {}
local consoleReady, consoleTimer, consoleTries = false, 0, 0

local function tryConsole(reason)
    local ok, why = game.enableConsole(config.consoleKeys)
    if ok then
        if not consoleReady then
            log("Konsole freigeschaltet (" .. reason .. "). Taste: " .. table.concat(config.consoleKeys or {}, " / "))
        end
        consoleReady = true
    else
        dbg("Konsole noch nicht bereit: " .. tostring(why))
    end
    return ok
end

local lastTime
local function frameDelta()
    local now = cheats.active() and game.realTime() or nil
    local dt = 0.016
    if now and lastTime then dt = now - lastTime end
    lastTime = now
    if dt < 0.001 then dt = 0.001 elseif dt > 0.1 then dt = 0.1 end
    return dt
end

local function driverTick()
    local dt = frameDelta()

    -- Konsole freischalten, sobald der Viewport existiert (alle ~2 s, max. 60 Versuche)
    if not consoleReady and consoleTries < 60 then
        consoleTimer = consoleTimer - dt
        if consoleTimer <= 0 then
            consoleTimer, consoleTries = 2.0, consoleTries + 1
            tryConsole("Start")
        end
    end

    if #pending > 0 then
        local queue = pending
        pending = {}
        for _, action in ipairs(queue) do
            local fn = cheats.actions[action]
            if fn then pcall(fn, log) end
        end
    end

    cheats.tick(dt)
end

local function safeTick()
    local ok, err = pcall(driverTick)
    if not ok then dbg("Tick-Fehler: " .. tostring(err)) end
end

if LoopInGameThreadWithDelay then
    LoopInGameThreadWithDelay(16, safeTick)
    dbg("Treiber: LoopInGameThreadWithDelay")
elseif LoopAsync and ExecuteInGameThread then
    -- Fallback fuer aeltere UE4SS-Builds: nie mehr als einen Tick gleichzeitig einreihen.
    local busy = false
    LoopAsync(16, function()
        if busy then return false end
        if consoleReady and #pending == 0 and not cheats.active() then return false end
        busy = true
        ExecuteInGameThread(function() safeTick(); busy = false end)
        return false
    end)
    dbg("Treiber: LoopAsync-Fallback")
else
    log("Keine Loop-Funktion verfuegbar - Godmode-Heilung, Fliegen und Hotkeys sind deaktiviert.")
end

-- ------------------------------------------------------------------ Hotkeys --
local bound = {}
if RegisterKeyBind and Key then
    for action, keyName in pairs(config.hotkeys) do
        if type(keyName) == "string" and keyName ~= "" and cheats.actions[action] then
            local k = Key[keyName]
            if k then
                local ok = pcall(RegisterKeyBind, k, function()
                    pending[#pending + 1] = action
                end)
                if ok then bound[#bound + 1] = keyName .. "=" .. action end
            else
                log("Unbekannte Taste in config.lua: " .. keyName .. " (" .. action .. ")")
            end
        end
    end
end

-- ------------------------------------------------------- Spielstand / Level --
local function onWorldChanged(reason)
    game.clearCaches()
    cheats.onWorldChanged()
    tryConsole(reason)
end

if RegisterInitGameStatePostHook then
    pcall(RegisterInitGameStatePostHook, function() pcall(onWorldChanged, "Spielstand") end)
end
if RegisterHook then
    pcall(RegisterHook, "/Script/Engine.PlayerController:ClientRestart", function()
        pcall(game.clearCaches)
    end)
end

log(string.format("v%s geladen: %d Befehle, Hotkeys: %s. Konsole oeffnen und 'marvin' eingeben.",
    VERSION, count, #bound > 0 and table.concat(bound, ", ") or "keine"))
