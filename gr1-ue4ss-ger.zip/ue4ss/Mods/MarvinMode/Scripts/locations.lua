-- MarvinMode - feste Teleport-Ziele (Weltkoordinaten in cm).
-- Eigene Ziele: im Spiel "savepos <name>" eingeben (landet in saved_positions.txt),
-- oder hier einen Eintrag ergänzen. "pos" zeigt die aktuelle Position an.
-- id = das, was man nach "tp" tippt; aliases = weitere Schreibweisen.

return {
    { id = "altlager",   name = "Altes Lager",            x = 119636, y = -95498,  z = -5330, aliases = { "oldcamp", "al" } },
    { id = "burg",       name = "Altes Lager (Burg)",     x = 111954, y = -102508, z = -3680, aliases = { "castle", "gomez" } },
    { id = "neulager",   name = "Neues Lager",            x = 168754, y = -85752,  z = -242,  aliases = { "newcamp", "nl" } },
    { id = "sumpf",      name = "Sumpflager",             x = 52178,  y = -115089, z = -8871, aliases = { "sumpflager", "swampcamp", "psi" } },
    { id = "altemine",   name = "Alte Mine",              x = 146198, y = -69089,  z = -3475, aliases = { "oldmine" } },
    { id = "freiemine",  name = "Freie Mine",             x = 167731, y = -122412, z = 3595,  aliases = { "freemine" } },
    { id = "austausch",  name = "Austauschplatz",         x = 103627, y = -58695,  z = 2504,  aliases = { "exchange", "tauschplatz" } },
}
