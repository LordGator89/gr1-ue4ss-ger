-- MarvinMode - Konfiguration
-- Nach Änderungen das Spiel neu starten (oder im UE4SS-Fenster STRG+R für Hot-Reload).

return {
    -- Tasten, die die Ingame-Konsole öffnen (zusätzlich zu den UE4SS-Standards).
    -- Unreal-Tastennamen: "F10", "Tilde" (auf deutscher Tastatur meist Ö), "F2" ...
    consoleKeys = { "F10", "Tilde" },

    -- Hotkeys (UE4SS-Tastennamen, z. B. "F6", "PAGE_UP", "HOME", "END", "NUM_FIVE").
    -- Auf "" setzen, um einen Hotkey zu deaktivieren.
    hotkeys = {
        god        = "F6",        -- Godmode an/aus
        full       = "F7",        -- Leben, Mana, Sauerstoff auffüllen, Müdigkeit weg
        fly        = "F8",        -- Fliegen an/aus
        tpForward  = "PAGE_UP",   -- ein Stück nach vorne teleportieren (wie Marvin-Taste K)
        savePos    = "HOME",      -- aktuelle Position als "hotkey" merken
        loadPos    = "END",       -- zur gemerkten Position "hotkey" springen
        tpBack     = "PAGE_DOWN", -- zurück zur Position vor dem letzten Teleport
    },

    tpForwardMeters = 6,      -- Distanz für tpf / Hotkey ohne Angabe (Meter)
    flySpeed        = 1500,   -- Fluggeschwindigkeit in cm/s
    godHealInterval = 0.25,   -- Sekunden zwischen Godmode-Nachheilungen
    landingHold     = 2.5,    -- Sekunden, die man nach einem Fern-Teleport festgehalten wird,
                              -- damit die Welt nachladen kann (verhindert Durchfallen)

    -- Optionales Präfix für alle Befehle (z. B. "mm_"), falls ein anderer Mod
    -- gleichnamige Befehle registriert. Leer = keine Präfixe.
    commandPrefix = "",

    -- Zusätzliche Ausgaben im UE4SS-Log
    debug = false,
}
